﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication17.DTO
{
    class BankAccountDTO
    {
        public int Id { get; set; }
        public int IdClient { get; set; }
        public int IdCurrency { get; set; }
        public int IdBank { get; set; }
        public string IBAN { get; set; }
        public double Sold { get; set; }
    }
}
