﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication17.DTO
{
    class CurrencyDTO
    {
        public string CurrencyAbbreviation { get; set; }
        public string CurrencyName { get; set; }
    }
}
