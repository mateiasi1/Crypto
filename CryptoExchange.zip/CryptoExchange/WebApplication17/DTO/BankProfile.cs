﻿using System;
using System.Collections.Generic;
using System.Text;
using WebApplication17.Models;
using AutoMapper;
using AutoMapper.Mappers;
using WebApplication17.Data;
using WebApplication17.Data.Registration;
using WebApplication17.Wallet;
using WebApplication17.DTO;

namespace ClassLibrary1.DTO
{
    class BankProfile : Profile
    {
        public BankProfile()
        {
            CreateMap<Bank, BankDTO>();
            CreateMap<BankAccount, BankAccountDTO>();
            CreateMap<BankAccountTransaction, BankAccountTransactionDTO>();
            CreateMap<ClientCurrency, ClientCurrencyDTO>();
            CreateMap<ClientDetails, ClientDetailsDTO>();
            CreateMap<Conversion, ConversionDTO>();
            CreateMap<ConversionTransaction, ConversionTransactionDTO>();
            CreateMap<Crypto, CryptoDTO>();
            CreateMap<Currency, CurrencyDTO>();
            CreateMap<Fee, FeeDTO>();
            CreateMap<FlatRateFee, FlatRateFeeDTO>();
            CreateMap<Login, LoginDTO>();
            CreateMap<RegisterUser, RegisterUserDTO>();
            CreateMap<Token, TokenDTO>();
            CreateMap<User, UserDTO>();
            CreateMap<Wallet, WalletDTO>();
        }
    }
}
