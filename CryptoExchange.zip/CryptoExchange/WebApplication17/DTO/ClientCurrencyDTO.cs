﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication17.DTO
{
    class ClientCurrencyDTO
    {
    }
}
