﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1.DTO
{
    public class BankDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CUI { get; set; }
        public string Adress { get; set; }
        public string Country { get; set; }
    }
}
