﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication17.Models
{
public class FlatRateFee
{
public int Id { get; set; }
public double Ammount { get; set; }
public bool Obsolete { get; set; }
}
}
