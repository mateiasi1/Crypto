﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication17.Data;
using WebApplication17.Models;

namespace WebApplication17.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly Contexts _context;

        public UsersController(Contexts context)
        {
            _context = context;
        }
        [Route("api/[controller]/addcurrency")]
        [HttpPost]
        public async Task<ActionResult<Currency>> PostUser(Currency currency, int UserId)
        {
            var currentUser = await _context.User.FindAsync(UserId);
            if (currentUser.Role == "admin")
            {
                _context.Currency.Add(currency);
                await _context.SaveChangesAsync();
                return Ok("Currency succesfull added");
            }
            else
            {
                return NotFound("Only andmin users can add a currency!");
            }
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUses()
        {
            return await _context.User.ToListAsync();
        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _context.User.FindAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }


        // GET: api/Users/Confirmed - return the list of unconfirmed users
        [HttpGet("{Confirmed}")]
        public async Task<ActionResult<User>> GetUnconfirmedUsers(bool confirmed)
        {
            List<User> users = await _context.User.Where(u => u.Confirmed == confirmed).ToListAsync();

            if (users == null)
            {
                return NotFound();
            }
            foreach (var user in users)
            {

            }
            return Ok();
        }
        // PUT: api/Users
        [HttpPut]
        public async Task<IActionResult> PutUser([FromBody]int id)
        {
            var user = await _context.User.FindAsync(id);
            if (id != user.Id)
            {
                return BadRequest();
            }
            user.Password = null;
            await _context.SaveChangesAsync();
            _context.Entry(user).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            // de legat de serviciul de email si de trimis GUID + Id in link ul de email pentru resetare
            return Ok();
        }

        // PUT: api/Users/confirmed
        [HttpPut("{Confirmed}")]
        public async Task<IActionResult> ConfirmUser([FromBody]int id, bool confirmed)
        {
            var user = await _context.User.FindAsync(id);
            if (id != user.Id)
            {
                return BadRequest();
            }
            user.Confirmed = true;
            await _context.SaveChangesAsync();
            _context.Entry(user).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            // de legat de serviciul de email si de trimis GUID + Id in link ul de email pentru resetare
            return Ok();
        }

        // POST: api/Users reset password
        [HttpPost]
        public async Task<ActionResult> PostUser([FromBody]int id, string password, string token)
        {
            var user = await _context.User.FindAsync(id);
            if (UserExists(id) && user.Token == token)
            {
                var passwordSalt = new Salt();
                string passwordHash = Hash.Create(user.Password, passwordSalt.ToString());
                user.Password = passwordHash;
                await _context.SaveChangesAsync();
                return Ok();
            }
            else
            {
                return BadRequest();
            }

        }

        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteUser(int id)
        {
            var user = await _context.User.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.User.Remove(user);
            await _context.SaveChangesAsync();

            return Ok();
        }

        private bool UserExists(int id)
        {
            return _context.User.Any(e => e.Id == id);
        }
    }
}
