﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using WebApplication17.Data;
using WebApplication17.Models;

namespace WebApplication17.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetCryptoCurrencyAPI : Controller
    {
        private readonly Contexts _context;

        public GetCryptoCurrencyAPI(Contexts context)
        {
            _context = context;
        }

        //[HttpGet]
        //public IActionResult GetById()
        //{
        //    var client = new RestClient("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD,JPY,EUR");
        
        //    var request = new RestRequest(Method.GET);
        //    IRestResponse response = client.Execute(request);
        //    var content = JsonConvert.DeserializeObject<JToken>(response.Content);
        //    //TODO: transform the response here to suit your needs
        //    //Get the league caption
        //    var leagueCaption = content["leagueCaption"].Value<string>();

        //    //Get the standings for the league.
        //    var rankings = content.SelectTokens("standing[*]")
        //        .Select(team => new Crypto
        //        {
        //            Name = (string)team["USD"],
        //            Price = (int)team["position"]
        //        })
        //        .ToList();

        //    return Ok();
        //}
        // GET: /<controller>/
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Currency>>> GetCurrencyFromAPI()
        {

            List<Crypto> crypto = new List<Crypto>();
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri("https://min-api.cryptocompare.com/data/price");
                    var response = await client.GetAsync($"?fsym=BTC&tsyms=USD,JPY,EUR?2149e65731f02e67abf4fd485d77e24a88931fe884fb974841718fd3a37b4e38");
                    response.EnsureSuccessStatusCode();

                    var stringResult = await response.Content.ReadAsStringAsync();
                    var jsonData = JObject.Parse(stringResult);
                    foreach (var item in jsonData)
                    {
                        Crypto cryptoObj = new Crypto();
                        cryptoObj.Name = item.Key;
                        cryptoObj.Price = Convert.ToDouble(item.Value);
                        crypto.Add(cryptoObj);
                    }
                    return Ok(crypto);
                }
                catch (HttpRequestException httpRequestException)
                {
                    return BadRequest($"Error getting crypto: {httpRequestException.Message}");
                }
            }
        }
    }
}
