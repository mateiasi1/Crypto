﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication17.Models;
using ClassLibrary1.DTO;

namespace WebApplication17.AutoMapperConfig
{
    public class AutoMapperConfig
    {
       
        //var config = new MapperConfiguration(cfg =>
        //{
        //    cfg.CreateMap<Bank, BankDTO>();
        //});
        //IMapper iMapper = config.CreateMapper();

    }
}
