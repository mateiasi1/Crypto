﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication17.Models
{
public class Currency
{
public int Id { get; set; }
public string CurrencyAbbreviation { get; set; }
public string CurrencyName { get; set; }
public string Status { get; set; }
}
}
